from fastapi.testclient import TestClient
from api_provider import app as provider_app


def test_token_and_users_flow():
    client = TestClient(provider_app)

    # solicita token
    r = client.get("/token")
    assert r.status_code == 200
    token = r.json().get("token")
    assert token is not None and isinstance(token, str)

    # usa token para acessar /usuarios
    r2 = client.get("/usuarios", params={"token": token})
    assert r2.status_code == 200
    data = r2.json()
    assert "usuarios" in data
    assert isinstance(data["usuarios"], list)
    assert any(isinstance(u.get("nome"), str) for u in data["usuarios"])
